(function() {
	app.controller("myController", myController);	
	myController.$inject = [ "$scope", "$http"];
	
	function myController($scope, $http) {
		
		$scope.chart = function(){
			$http.get("http://localhost:8080/FinancialReportingTool/project/getAll"
	           
			) .success(function (data) {
				
				var data2 = [];
				for(var i in data){					
					 data2.push([data[i].projectName,data[i].actualProjectMargin, data[i].cost, data[i].revenue]);
				}
				
				console.log(data2);				
				
				google.charts.load("visualization", "1", {packages:["corechart", "table"]});
				 
				google.charts.setOnLoadCallback(drawChart);	
				
				
				function drawChart() {						
				
				var data1 = new google.visualization.DataTable();
				data1.addColumn('string', 'Project');
				data1.addColumn('number', 'Margin');	
				data1.addColumn('number', 'Cost');
				data1.addColumn('number', 'Revenue');								
				data1.addRows(data2);					
					
				var options = {
				       
						 legend: {position: 'top', maxLines: 3},
					      connectSteps: false,
					      colors: ['#4374E0', '#fda449', '#029f29', '#d60603'],
					      isStacked: true,
					      
				  };			
				
				var chart = new google.visualization.SteppedAreaChart(document.getElementById('chart_div'));
				chart.draw(data1, options);						
				
			}
				
			});
	            
		}();
	};
})();
