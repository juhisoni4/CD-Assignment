(function() {
	app.controller("myController", myController);	
	myController.$inject = [ "$scope", "$http"];
	
	function myController($scope, $http) {
		
		$scope.chart = function(){
			$http.get("http://localhost:8080/FinancialReportingTool/project/data"
	           
			) .success(function (data) {				
				
				google.charts.load("visualization", "1", {packages:["corechart", "table"]});
				 
				google.charts.setOnLoadCallback(drawChart);	
				
				
				function drawChart() {						
				
				var data1 = google.visualization.arrayToDataTable([
					                                              [data.projectName, 'FinanceData'],
					                                              ['Revenue',data.revenue],
					                                              ['Cost', data.cost],
					                                              ['Margin',data.actualProjectMargin],
					                                              ['MarginPercentage',data.actualProjectMarginPercentage]                   
					                                              ]);				
				var options = {
						
			   };			
				
				var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
				chart.draw(data1, options);						
				
			}
				
			});
	            
		}();
	};
})();
