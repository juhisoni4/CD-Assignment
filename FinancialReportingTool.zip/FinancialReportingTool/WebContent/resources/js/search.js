(function(){
	
	'user strict';
	
	angular.module('SearchApp',[])
	.controller('SearchController',SearchController)
	.service('SearchService',SearchService)
	.directive('autoComplete',AutoComplete);
	
	AutoComplete.$inject = ['$timeout'];
	function AutoComplete($timeout){		
		  return function(scope, iElement, iAttrs) {
        scope.$watch(iAttrs.uiItems, function(newValue, oldValue){
         if(newValue) {
          iElement.autocomplete({
                    source: scope[iAttrs.uiItems],
                    select: function() {
                        $timeout(function() {
                          iElement.trigger('input');
                        }, 0);
                    }
                });
         }
        });
    };	
	}
	

	
	SearchController.$inject = ['$scope', 'SearchService'];
	function SearchController($scope, SearchService){
		
		var search = this;
		search.getData = function() {
			search.subProject = SearchService.getAllData();
		}();
		console.log(search.subProject);
	};
	
	SearchService.$inject = ['$http'];
	function SearchService($http){
		
		var service = this;
		
		
		service.getAllData = function(){
			
			var subProject = [];
			
			$http.get("http://localhost:8080/FinancialReportingTool/subProject/getAll"			           
			).success(function (response) {
				
				var subProjectData = response;
				console.log("Subproject: ");
				console.log(subProjectData);
				console.log(response.length);
				
				  for (var i=0;i<subProjectData.length;i++){
				      
				       console.log("in forrr of project");
				       subProject.push( subProjectData[i].subProjectName);
				    }
				
				/*for(var i = 0;i<subProjectData.length;i++){	
					 console.log("in forrr of project");
					console.log(subProjectData[i].subProjectName);
					subProject.push(subProjectData[i].subProjectName);
				}*/	
				console.log(subProject);
				
			});			
			return subProject;
		};
		
	}	
		
		
})();