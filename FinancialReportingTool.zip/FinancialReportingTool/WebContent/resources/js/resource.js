/*(function() {
	app.controller("myController", myController);	
	myController.$inject = [ "$scope", "$http"];
	
	function myController($scope, $http) {
		google.charts.load("visualization", "1", {packages:["corechart", "table"]});
		$scope.chart = function(){
			$http.get("http://localhost:8080/FinancialReportingTool/employee/resource"
	           
			) .success(function (data) {
				
				console.log(data);
				var data2 = [];
				for(var i in data){					
					 data2.push([data[i].resourceName, data[i].revenue, data[i].cost, data[i].actualProjectMargin,data[i].actualProjectMarginPercentage]);
				}
									
				var i,j,data3,part = 10;				
				
				console.log(data2);	
				
					var data1 = [];
					
					data1[0] = new google.visualization.DataTable();
					data1[0].addColumn('string', 'Month');
					data1[0].addColumn('number', 'Revenue');
					data1[0].addColumn('number', 'Cost');
					data1[0].addColumn('number', 'Margin');
					data1[0].addColumn('number', 'MarginPercentage');
					data[0].addRows(data2);	
					
					data1[1] = new google.visualization.DataTable();
					data1[1].addColumn('string', 'Month');
					data1[1].addColumn('number', 'Revenue');
					data1[1].addColumn('number', 'Cost');
					data1[1].addColumn('number', 'Margin');
					data1[1].addColumn('number', 'MarginPercentage');
					
					for (i=0,j=array.length; i<j; i+=part) {
						data3 = data2.slice(i,i+part);						
						data[1].addRows(data3);	
						
						var options = {				
								vAxis: {title: 'Revenue'},
								hAxis: {title: 'Month'},	 
								seriesType: 'bars',
								backgroundColor: '#f0f0f0',
							    series: {3: {type: 'line', pointSize: 3}}
							};				
							
							var current = 0;					
							var button = document.getElementById('b1');
							var chart = new google.visualization.ComboChart(document.getElementById('chart_div'));
								 
							function drawChart() {
								
							button.disabled = true;
							google.visualization.events.addListener(chart, 'ready',
							function() {
							      button.disabled = false;					            
							});				      

							chart.draw(data1[current], options);
							
							}
							
							setTimeout(function() {
								drawChart();
							}, 5000)();
							
							//google.charts.setOnLoadCallback(drawChart);		
							

							button.onclick = function() {
							current = 1 - current;
							setTimeout(function() {
								drawChart();
							}, 5000)();
							//drawChart();
							//google.charts.setOnLoadCallback(drawChart);	
								
						   };						   
					}				
			});
	      
		}();
	};
})();*/
(function() {
	app.controller("myController", myController);	
	myController.$inject = [ "$scope", "$http"];
	
	function myController($scope, $http) {
		
		var data3 = [];
		
		google.charts.load("visualization", "1", {packages:["corechart", "table"]});
		
		var options = {				
				vAxis: {title: 'Revenue'},
				hAxis: {title: 'Month'},	 
				seriesType: 'bars',
				backgroundColor: '#f0f0f0',
			    series: {3: {type: 'line', pointSize: 3}}
			};	
		
		$scope.chart = function(){
			$http.get("http://localhost:8080/FinancialReportingTool/employee/resource"
	           
			) .success(function (data) {	
				
				var data4 = [];
				var data2 = [];
				
				for(var i in data){					
					data2.push([data[i].resourceName,  data[i].revenue,  data[i].cost, data[i].actualProjectMargin,data[i].actualProjectMarginPercentage]);
				}
				
				var len = data2.length/2;
				
				for(var j = len; j<data2.length; j++){
					
					data3.push(data2[j]);
				}
				
				for(var j = 0; j<len; j++){
					
					data4.push(data2[j]);
				}
				
				console.log(data2);	
				
				 
				google.charts.setOnLoadCallback(drawChart);		
				
				
				function drawChart() {						
				
				var data1 = new google.visualization.DataTable();
				data1.addColumn('string', 'Resourse');	
				data1.addColumn('number', 'Revenue');
				data1.addColumn('number', 'Cost');
				data1.addColumn('number', 'Margin');
				data1.addColumn('number', 'MarginPercentage');				
				data1.addRows(data4);	
					 
				var chart = new google.visualization.ComboChart(document.getElementById('chart_div'));
				chart.draw(data1, options);						
				
			}
				
			});
	            
		}();
		
		$scope.chart1 = function(){
			
			var data1 = new google.visualization.DataTable();
			data1.addColumn('string', 'Resourse');	
			data1.addColumn('number', 'Revenue');
			data1.addColumn('number', 'Cost');
			data1.addColumn('number', 'Margin');
			data1.addColumn('number', 'MarginPercentage');			
			data1.addRows(data3);	
			
			var chart = new google.visualization.ComboChart(document.getElementById('chart_div'));
			chart.draw(data1, options);	
		};
	};
})();
