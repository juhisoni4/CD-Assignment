package com.frt.model.DTO;

public class FinancialDataDTO {
	
	private String month;
	
	private double revenue;
	
	private double cost;
	
	private double actualProjectMargin;
	
	private double actualProjectMarginPercentage;	
	
	private String clientName;	
	
	private String projectName;	
	
	private String resourceName;
	
	public FinancialDataDTO() {
		
	}
	
	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public double getRevenue() {
		return revenue;
	}

	public void setRevenue(double revenue) {
		this.revenue = revenue;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public double getActualProjectMargin() {
		return actualProjectMargin;
	}

	public void setActualProjectMargin(double actualProjectMargin) {
		this.actualProjectMargin = actualProjectMargin;
	}

	public double getActualProjectMarginPercentage() {
		return actualProjectMarginPercentage;
	}

	public void setActualProjectMarginPercentage(
			double actualProjectMarginPercentage) {
		this.actualProjectMarginPercentage = actualProjectMarginPercentage;
	}
	
	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}	

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	@Override
	public String toString() {
		return "FinancialDataDTO [month=" + month + ", revenue=" + revenue
				+ ", cost=" + cost + ", actualProjectMargin="
				+ actualProjectMargin + ", actualProjectMarginPercentage="
				+ actualProjectMarginPercentage + ", clientName=" + clientName
				+ ", projectName=" + projectName + ", resourceName="
				+ resourceName + "]";
	}	
	
}
