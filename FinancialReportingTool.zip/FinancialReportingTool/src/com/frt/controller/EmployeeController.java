package com.frt.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.frt.model.Client;
import com.frt.model.Employee;
import com.frt.model.Employee.Role;
import com.frt.model.FinancialData;
import com.frt.model.DTO.FinancialDataDTO;
import com.frt.service.EmployeeService;
import com.frt.service.FinancialDataService;

@RestController
@RequestMapping(value = "/employee")
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;

	@Autowired
	FinancialDataService financialDataService;

	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

	public void saveEmployee(Employee employee) {

		employeeService.saveEmployee(employee);
	}

	public Employee getEmployeeById(Long id) {

		Employee employee = employeeService.getEmployeetById(id);
		return employee;
	}

	public List<Employee> getAllEmployee() {

		List<Employee> employeeList = new ArrayList<>();
		employeeList = employeeService.getAllEmployee();
		return employeeList;
	}

	@RequestMapping(value = "/projectManager")
	public List<FinancialDataDTO> getFinanceDataByProjectManager() {

		long start = System.currentTimeMillis();

		List<FinancialDataDTO> financialDataDTOList1 = new ArrayList<>();

		Employee employee = new Employee();
		employee.setName("Vatsal Thakkar");
		employee.setRole(Role.Project_Manager);

		List<Employee> employeeList = employeeService.search(employee);
		employee = employeeList.get(0);

		String typeOfFinanceData = "Revenue";
		String typeOfFinanceData1 = "Cost";
		String date = "2016-04-01";
		String date3 = "2017-03-01";
		Date date1 = null;
		Date date2 = null;
		try {
			date1 = formatter.parse(date);
			date2 = formatter.parse(date3);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		List<FinancialData> financeDataList = employeeService
				.getFinanceDataByProjectManager(employee, date1, date2);
		System.out.println(financeDataList);

		int year1 = Integer.parseInt(date.substring(0, 4));
		System.out.println(year1);

		int year2 = Integer.parseInt(date3.substring(0, 4));
		System.out.println(year2);

		financialDataDTOList1 = financialDataService.calculateDataByYear(
				financeDataList, typeOfFinanceData, typeOfFinanceData1, year1,
				year2);
		long end = System.currentTimeMillis();

		System.out.println("Time taken: " + (end - start) + " ms for ");

		return financialDataDTOList1;

	}

	@RequestMapping(value = "/resource")
	public Set<FinancialDataDTO> getFinanceDataByResources() {

		long start = System.currentTimeMillis();

		Set<FinancialDataDTO> financialDataDTOList1 = new HashSet<>();
		// List<FinancialDataDTO> financialDataDTOList2 = new ArrayList<>();

		List<FinancialData> financialDataList = employeeService
				.getFinanceDataOfResources();

		Set<String> list = new HashSet<>();
		list.add("Cignex Datametics");
		
		int i = 0;
		
		/*for(FinancialData financialData:financialDataList){			
			String name = financialData.getProjectResource().getName();
			//String code = financialData.getProjectResource().getResourceCode();
			list.add(name);
		}*/
		
		for(FinancialData financialData:financialDataList){
			
			double revenue = 0.0;
			double cost = 0.0;
			double margin = 0.0;
			double marginPercentage = 0.0;
			
			String name = financialData.getProjectResource().getName();
			String code = financialData.getProjectResource().getResourceCode();
			System.out.println(name);
			
			boolean flag = list.contains(code);
			System.out.println(flag);
			
			if(!(list.contains(code))){
				
			list.add(code);	
			
			for(int k = 0; k < financialDataList.size(); k++){
			
			if(code.equals(financialDataList.get(k).getProjectResource().getResourceCode())){				
				revenue += financialDataList.get(k).getActualRevenue();
				cost += financialDataList.get(k).getActualCost();
				
			}	
			
			}
			
			if(revenue != 0.0 & cost != 0.0){				
				margin = revenue - cost;
				marginPercentage = (margin/revenue)*100;
				FinancialDataDTO financialDataDTO = new FinancialDataDTO();
				financialDataDTO.setResourceName(name);
				financialDataDTO.setCost(cost);
				financialDataDTO.setActualProjectMargin(margin);
				financialDataDTO.setActualProjectMarginPercentage(marginPercentage);
				financialDataDTO.setRevenue(revenue);
				financialDataDTOList1.add(financialDataDTO);				
				financialDataDTOList1 = objectFactory(financialDataDTOList1, revenue, cost, margin, marginPercentage, name);				
			}
			
			}
			
			i++;
			
		}
			 
		
		
		long end = System.currentTimeMillis();

		System.out.println("Time taken: " + (end - start) + " ms for ");

		return financialDataDTOList1;

	}

	public Set<FinancialDataDTO> objectFactory(
			Set<FinancialDataDTO> financialDataDTOList, double revenue,
			double cost, double margin, double marginPercentage, String name) {

		FinancialDataDTO financialDataDTO = new FinancialDataDTO();
		financialDataDTO.setResourceName(name);
		financialDataDTO.setCost(cost);
		financialDataDTO.setActualProjectMargin(margin);
		financialDataDTO.setActualProjectMarginPercentage(marginPercentage);
		financialDataDTO.setRevenue(revenue);
		financialDataDTOList.add(financialDataDTO);

		return financialDataDTOList;

	}
}
