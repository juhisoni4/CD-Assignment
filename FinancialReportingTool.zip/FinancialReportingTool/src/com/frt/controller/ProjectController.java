package com.frt.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.frt.model.FinancialData;
import com.frt.model.Project;
import com.frt.model.DTO.FinancialDataDTO;
import com.frt.service.FinancialDataService;
import com.frt.service.ProjectService;

@RestController
@RequestMapping(value="/project")
public class ProjectController {

	@Autowired
	ProjectService projectService;
	
	@Autowired
	FinancialDataService financialDataService;
	
	@RequestMapping(value = "/data")
	public FinancialDataDTO getProjectDataByProjectName(){
		
		Project project = new Project();
		project.setProjectNamePerQuest("IBM User Management Portal");
		
		List<Project> projectList = projectService.search(project);
		project = projectList.get(0);
		
		List<FinancialData> financialDataList = projectService.getFinanceDataByProject(project);
		
		System.out.println(financialDataList);		
		
		double data[] = calculateRevenueCost(financialDataList);
		
		System.out.println(data[0]);
		System.out.println(data[1]);
		System.out.println(data[2]);
		System.out.println(data[3]);
		
		FinancialDataDTO financialDataDTO = new FinancialDataDTO();		
		
		financialDataDTO.setProjectName(project.getProjectNamePerQB());
		financialDataDTO.setRevenue(data[0]);
		financialDataDTO.setCost(data[1]);
		financialDataDTO.setActualProjectMargin(data[2]);
		financialDataDTO.setActualProjectMarginPercentage(data[3]);		
		
		return financialDataDTO;	
		
	}
	
	@RequestMapping(value = "/getAll")
	public List<FinancialDataDTO> getAllProjectData(){
		
		long start = System.currentTimeMillis();

		List<FinancialDataDTO> financialDataDTOList1 = new ArrayList<>();		
		
		List<Project> ProjectList = projectService.getAllProject();	

		for (Project Project : ProjectList) {
			
			FinancialDataDTO financialDataDTO = new FinancialDataDTO();			
			
			List<FinancialData> financeDataList = projectService
					.getFinanceDataByProject(Project);
			
			double revenue = 0.0 ;
			double cost = 0.0;		
			
			for(FinancialData financialData:financeDataList){				
				revenue += financialData.getActualRevenue();
				cost += financialData.getActualCost();		
			}
			
			double margin =  revenue - cost;
			double marginPer = (margin/revenue)*100;
			financialDataDTO.setProjectName(Project.getProjectNamePerQB());
			financialDataDTO.setRevenue(revenue);
			financialDataDTO.setCost(cost);
			financialDataDTO.setActualProjectMargin(margin);
			financialDataDTO.setActualProjectMarginPercentage(marginPer);		
			
			financialDataDTOList1.add(financialDataDTO);

		}
		
		long end = System.currentTimeMillis();

		System.out.println("Time taken: " + (end - start) + " ms for ");
		
		return financialDataDTOList1;
		
	}
	

	
	
	public void saveProject(Project project){
		
		projectService.saveProject(project);
	}
	
	public void getProjectById(Long id){
		
		Project project = projectService.getProjectById(id);
				
	}
	
	public void getAllProject(){
		
		List<Project> projectList = projectService.getAllProject();
	}
	
	public double[] calculateRevenueCost(List<FinancialData> financialDataList){
		
		double revenue = 0.0 ;
		double cost = 0.0;	
		double data[] = new double[4];
		
		for(FinancialData financialData:financialDataList){				
			revenue += financialData.getActualRevenue();
			cost += financialData.getActualCost();		
		}
		
		double margin =  revenue - cost;
		double marginPer = (margin/revenue)*100;
		
		data[0] = revenue;
		data[1] = cost;
		data[2] = margin;
		data[3] = marginPer;
		
		System.out.println(revenue);
		System.out.println(cost);
		System.out.println(margin);
		System.out.println(marginPer);
		
		return data;
		
	}
	

}
