package com.frt.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.frt.model.Client;
import com.frt.model.FinancialData;
import com.frt.model.FinancialData.Month;
import com.frt.model.DTO.FinancialDataDTO;
import com.frt.service.ClientService;
import com.frt.service.FinancialDataService;
import com.frt.util.Util;

@RestController
@RequestMapping(value = "/financeData")
public class FinancialDataController {

	@Autowired
	ClientService clientService;

	@Autowired
	FinancialDataService financialDataService;

	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	
	/**Below method will calculate the total revenue, cost, margin and marginPercentage of 
	 * selected year	  
	 */

	@RequestMapping(value = "/totality")
	public List<FinancialDataDTO> getFinanceDataOfYear() {

		long start = System.currentTimeMillis();		
		
		String typeOfFinanceData = "Revenue";
		String typeOfFinanceData1 = "Cost";
		
		String date = "2015-04-01";
		String date3 = "2016-03-01";
		Date date1 = null;
		Date date2 = null;
		try {
			date1 = formatter.parse(date);
			date2 = formatter.parse(date3);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		int year1 = Integer.parseInt(date.substring(0, 4));
		System.out.println(year1);

		int year2 = Integer.parseInt(date3.substring(0, 4));
		System.out.println(year2);

		
		List<FinancialData> financeDataList = financialDataService
				.getFinancialDataOfYear(date1, date2);

		List<FinancialDataDTO> financialDataDTOList1 = financialDataService.calculateDataByYear(financeDataList, typeOfFinanceData, typeOfFinanceData1, year1, year2);
		
		long end = System.currentTimeMillis();
		
		System.out.println("Time taken: " + (end - start) + " ms for ");

		return financialDataDTOList1;
	}

	@RequestMapping(value = "/list3")
	public List<FinancialDataDTO> getFinanceDataByClient() {

		long start = System.currentTimeMillis();		
	
		Client client = new Client();
		client.setClientName("IBM");

		List<Client> clientList = clientService.search(client);
		client = clientList.get(0);

		String typeOfFinanceData = "Revenue";
		String typeOfFinanceData1 = "Cost";
		String date = "2015-04-01";
		String date3 = "2016-03-01";
		Date date1 = null;
		Date date2 = null;
		try {
			date1 = formatter.parse(date);
			date2 = formatter.parse(date3);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		List<FinancialData> financeDataList = financialDataService
				.getFinanceDataByClient(client, date1, date2, typeOfFinanceData);
		System.out.println(financeDataList);

		int year1 = Integer.parseInt(date.substring(0, 4));
		System.out.println(year1);

		int year2 = Integer.parseInt(date3.substring(0, 4));
		System.out.println(year2);
		
		List<FinancialDataDTO> financialDataDTOList1 = financialDataService.calculateDataByYear(financeDataList, typeOfFinanceData, typeOfFinanceData1, year1, year2);	

		long end = System.currentTimeMillis();

		System.out.println("Time taken: " + (end - start) + " ms for ");

		return financialDataDTOList1;

	}
	
	/** Below method will calculate the month wise finance data of onsite and offshore employee
	 */
	@RequestMapping(value = "/isOnSite")
	public List<FinancialDataDTO> getFinanceDataByOnSite() {

		long start = System.currentTimeMillis();	
		
		List<FinancialData> financialDataList1 = new ArrayList<>();
		List<FinancialData> financialDataList2 = new ArrayList<>();
		
		String date = "2015-04-01";
		String date3 = "2016-03-01";
		Date date1 = null;
		Date date2 = null;
		try {
			date1 = formatter.parse(date);
			date2 = formatter.parse(date3);
		} catch (ParseException e) {
			e.printStackTrace();
		}			
		
		List<FinancialData> financeDataList = financialDataService.getFinancialDataOfYear(date1, date2);
		
		int year1 = Integer.parseInt(date.substring(0, 4));
		System.out.println(year1);

		int year2 = Integer.parseInt(date3.substring(0, 4));
		System.out.println(year2);
		
		for(FinancialData financialData:financeDataList){
			
			boolean isOnSite = financialData.getIsOnSite();	
			
			if(isOnSite == true){
				financialDataList1.add(financialData);
			}else{
				financialDataList2.add(financialData);
			}			
			
		}
		
		List<FinancialDataDTO> financialDataDTOList1 = financialDataService.calculateDataByYear(financialDataList1, "Revenue", "", year1, year2);	
		List<FinancialDataDTO> financialDataDTOList2 = financialDataService.calculateDataByYear(financialDataList2, "Revenue", "", year1, year2);	

		int i = 0;
		
		for(FinancialDataDTO financialDataDTO:financialDataDTOList2){			
			financialDataDTOList1.get(i).setCost(financialDataDTO.getRevenue());			
			i++;
		}		
		
		long end = System.currentTimeMillis();

		System.out.println("Time taken: " + (end - start) + " ms for ");

		return financialDataDTOList1;

	}
	
	/**Below method will calculate the total revenue or cost or margin of onsite and
	 * offshore
	 * @return
	 */
	@RequestMapping(value = "/isOffShore")
	public List<FinancialDataDTO> getFinanceDataByOffshore() {

		long start = System.currentTimeMillis();	
		
		List<FinancialDataDTO> financialDataDTOList1 = new ArrayList<>();
		
		String date = "2015-04-01";
		String date3 = "2016-03-01";
		Date date1 = null;
		Date date2 = null;
		try {
			date1 = formatter.parse(date);
			date2 = formatter.parse(date3);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		boolean isOnSite = false;
		double revenue1 = 0.0;
		double revenue2 = 0.0;
		
		List<FinancialData> financeDataList = financialDataService.getFinancialDataOfYear(date1, date2);
		
		for(FinancialData financialData:financeDataList){
			
			isOnSite = financialData.getIsOnSite();
			
			if(isOnSite == true){
				revenue1 += financialData.getActualRevenue();
			}else{
				revenue2 += financialData.getActualRevenue();
			}
			
		}
		
		System.out.println(revenue1);
		System.out.println(revenue2);
		FinancialDataDTO financialDataDTO = new FinancialDataDTO();
		financialDataDTO.setRevenue(revenue1);		
		financialDataDTO.setProjectName("Onsite");
		
		FinancialDataDTO financialDataDTO2 = new FinancialDataDTO();
		financialDataDTO2.setRevenue(revenue2);		
		financialDataDTO2.setProjectName("OffShore");
		System.out.println();;
				
		financialDataDTOList1.add(financialDataDTO);
		financialDataDTOList1.add(financialDataDTO2);

		long end = System.currentTimeMillis();

		System.out.println("Time taken: " + (end - start) + " ms for ");

		return financialDataDTOList1;

	}


	public void saveFinancialData(FinancialData financialData) {

		financialDataService.saveFinanceData(financialData);
	}

	public FinancialData getFinancialDataById(Long id) {

		FinancialData financialData = financialDataService
				.getFinanceDataById(id);
		return financialData;
	}
		

	public List<FinancialData> getAllFinancialData() {

		List<FinancialData> financialDataList = new ArrayList<>();
		financialDataList = financialDataService.getAllFinanceData();
		return financialDataList;
	}		
	
}
