package com.frt.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.frt.model.Client;
import com.frt.model.FinancialData;
import com.frt.model.DTO.FinancialDataDTO;
import com.frt.model.FinancialData.Month;

public interface FinancialDataService {

	public void saveFinanceData(FinancialData financialData);

	public FinancialData getFinanceDataById(Long id);

	public List<FinancialData> getAllFinanceData();
	
	public List<FinancialData> getFinancialDataOfYear(Date date1, Date date2);	
	
	public List<FinancialData> getFinanceDataByClient(Client client,Date date1, Date date2,String typeOfData);	
	
	public List<FinancialData> search(FinancialData FinancialData);	
	
	public List<FinancialDataDTO> calculateFinanceData(
			List<FinancialDataDTO> financialDataDTOList,			
			List<FinancialData> financeDataList, String typeOfFinanceData,  String typeOfFinanceData1);
	
	public List<FinancialDataDTO> calculateDataByYear(
			List<FinancialData> financialDataList, String typeOfFinanceData,
			String typeOfFinanceData1, int year1, int year2);
}
