package com.frt.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.frt.model.Client;
import com.frt.model.FinancialData;
import com.frt.model.DTO.FinancialDataDTO;
import com.frt.model.FinancialData.Month;
import com.frt.repository.FinancialDataRepository;
import com.frt.service.FinancialDataService;
import com.frt.util.Util;

@Service
@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
public class FinancialDataServiceImpl implements FinancialDataService {

	@Autowired
	public FinancialDataRepository financialDataRepository;

	@Override
	public void saveFinanceData(FinancialData financialData) {

		financialDataRepository.saveFinanceData(financialData);
	}

	@Override
	public FinancialData getFinanceDataById(Long id) {

		FinancialData financialData = financialDataRepository
				.getaddFinanceDataById(id);
		return financialData;
	}

	@Override
	public List<FinancialData> getAllFinanceData() {

		List<FinancialData> financialDataList = new ArrayList<>();
		financialDataList = financialDataRepository.getAlladdFinanceData();
		return financialDataList;
	}

	@Override
	public List<FinancialData> search(FinancialData FinancialData) {

		return financialDataRepository.search(FinancialData);
	}

	@Override
	public List<FinancialData> getFinanceDataByClient(Client client,
			Date date1, Date date2, String typeOfData) {

		return financialDataRepository.getFinanceDataByClient(client, date1,
				date2, typeOfData);
	}

	@Override
	public List<FinancialData> getFinancialDataOfYear(Date date1, Date date2) {

		return financialDataRepository.getFinancialDataOfYear(date1, date2);
	}

	/** below method generate the FinancialDTO object and add that object to list	 * 
	 * @param financialDataDTOList
	 * @param totalRevenuePerMonth
	 * @param totalCostPerMonth
	 * @param month
	 * @return the list of FinanceDTO objects
	 */
	public List<FinancialDataDTO> objectFactory(
			List<FinancialDataDTO> financialDataDTOList,
			double totalRevenuePerMonth, double totalCostPerMonth, String month) {

		FinancialDataDTO financialDataDTO = new FinancialDataDTO();

		if (totalRevenuePerMonth != 0.0 & totalCostPerMonth != 0.0) {
			double margin = totalRevenuePerMonth - totalCostPerMonth;
			double marginPer = (margin / totalRevenuePerMonth) * 100;
			financialDataDTO.setActualProjectMargin(margin);
			financialDataDTO.setActualProjectMarginPercentage(marginPer);
		}

		financialDataDTO.setMonth(month);
		financialDataDTO.setRevenue(totalRevenuePerMonth);
		financialDataDTO.setCost(totalCostPerMonth);
		financialDataDTOList.add(financialDataDTO);
		return financialDataDTOList;
	}

	/** Below method will differentiate the finance data according to the month and calculate 
	 * the total revenue and cost of month. Then call objectFactory method that will return the 
	 * list of FinanceDTO object that contains the info of revenue, cost, margin and margin percentage.
	 */
	public List<FinancialDataDTO> calculateFinanceData(
			List<FinancialDataDTO> financialDataDTOList,
			List<FinancialData> financeDataList, String typeOfFinanceData,
			String typeOfFinanceData1) {

		double totalRevenue[] = new double[12];
		double totalCost[] = new double[12];
		int year = 0;

		for (FinancialData data : financeDataList) {

			double financeData = Util.get(data, typeOfFinanceData);
			Month month = data.getMonth();
			year = data.getYear();
			double financeData1 = 0.0;

			if (!typeOfFinanceData1.equals("")
					&& !typeOfFinanceData1.equals(null)) {

				financeData1 = Util.get(data, typeOfFinanceData1);
			}

			switch (month) {
			case JAN:
				totalRevenue[0] += financeData;
				if (financeData1 != 0.0)
					totalCost[0] += financeData1;
				break;

			case FEB:
				totalRevenue[1] += financeData;
				if (financeData1 != 0.0)
					totalCost[1] += financeData1;
				break;

			case MAR:
				totalRevenue[2] += financeData;
				if (financeData1 != 0.0)
					totalCost[2] += financeData1;
				break;

			case APR:
				totalRevenue[3] += financeData;
				if (financeData1 != 0.0)
					totalCost[3] += financeData1;
				break;

			case MAY:
				totalRevenue[4] += financeData;
				if (financeData1 != 0.0)
					totalCost[4] += financeData1;
				break;

			case JUN:
				totalRevenue[5] += financeData;
				if (financeData1 != 0.0)
					totalCost[5] += financeData1;
				break;

			case JUL:
				totalRevenue[6] += financeData;
				if (financeData1 != 0.0)
					totalCost[6] += financeData1;
				break;

			case AUG:
				totalRevenue[7] += financeData;
				if (financeData1 != 0.0)
					totalCost[7] += financeData1;
				break;

			case SEP:
				totalRevenue[8] += financeData;
				if (financeData1 != 0.0)
					totalCost[8] += financeData1;
				break;

			case OCT:
				totalRevenue[9] += financeData;
				if (financeData1 != 0.0)
					totalCost[9] += financeData1;
				break;

			case NOV:
				totalRevenue[10] += financeData;
				if (financeData1 != 0.0)
					totalCost[10] += financeData1;
				break;

			case DEC:
				totalRevenue[11] += financeData;
				if (financeData1 != 0.0)
					totalCost[11] += financeData1;
				break;
			}

		}

		if (totalRevenue[3] != 0.0 || totalCost[3] != 0.0) {
			financialDataDTOList = objectFactory(financialDataDTOList,
					totalRevenue[3], totalCost[3], "APR " + year);
		}
		if (totalRevenue[4] != 0.0 || totalCost[4] != 0.0) {
			financialDataDTOList = objectFactory(financialDataDTOList,
					totalRevenue[4], totalCost[4], "MAY " + year);
		}
		if (totalRevenue[5] != 0.0 || totalCost[5] != 0.0) {
			financialDataDTOList = objectFactory(financialDataDTOList,
					totalRevenue[5], totalCost[5], "JUN " + year);
		}
		if (totalRevenue[6] != 0.0 || totalCost[6] != 0.0) {
			financialDataDTOList = objectFactory(financialDataDTOList,
					totalRevenue[6], totalCost[6], "JUL " + year);
		}
		if (totalRevenue[7] != 0.0 || totalCost[7] != 0.0) {
			financialDataDTOList = objectFactory(financialDataDTOList,
					totalRevenue[7], totalCost[7], "AUG " + year);
		}
		if (totalRevenue[8] != 0.0 || totalCost[8] != 0.0) {
			financialDataDTOList = objectFactory(financialDataDTOList,
					totalRevenue[8], totalCost[8], "SEP " + year);
		}
		if (totalRevenue[9] != 0.0 || totalCost[9] != 0.0) {
			financialDataDTOList = objectFactory(financialDataDTOList,
					totalRevenue[9], totalCost[9], "OCT " + year);
		}
		if (totalRevenue[10] != 0.0 || totalCost[10] != 0.0) {
			financialDataDTOList = objectFactory(financialDataDTOList,
					totalRevenue[10], totalCost[10], "NOV " + year);
		}
		if (totalRevenue[11] != 0.0 || totalCost[11] != 0.0) {
			financialDataDTOList = objectFactory(financialDataDTOList,
					totalRevenue[11], totalCost[11], "DEC " + year);
		}		
		if (totalRevenue[0] != 0.0 || totalCost[0] != 0.0) {
			financialDataDTOList = objectFactory(financialDataDTOList,
					totalRevenue[0], totalCost[0], "JAN " + year);
		}
		if (totalRevenue[1] != 0.0 || totalCost[1] != 0.0) {
			financialDataDTOList = objectFactory(financialDataDTOList,
					totalRevenue[1], totalCost[1], "FEB " + year);
		}
		if (totalRevenue[2] != 0.0 || totalCost[2] != 0.0) {
			financialDataDTOList = objectFactory(financialDataDTOList,
					totalRevenue[2], totalCost[2], "MAR " + year);
		}

		return financialDataDTOList;

	}
	
	/** Below method differentiate the finance data according to the year and then call the
	 *  calculateFinanceData method that will calculate the revenue, cost, margin and margin percentage
	 *  and return the FinanceDTO object list. Then this method merge the year wise objects and
	 *  send it to front end. 
	 * */

	public List<FinancialDataDTO> calculateDataByYear(
			List<FinancialData> financialDataList, String typeOfFinanceData,
			String typeOfFinanceData1, int year1, int year2) {

		List<FinancialData> financialDataList1 = new ArrayList<>();
		List<FinancialData> financialDataList2 = new ArrayList<>();
		List<FinancialData> financialDataList3 = new ArrayList<>();

		List<FinancialDataDTO> financialDataDTOList1 = new ArrayList<>();
		List<FinancialDataDTO> financialDataDTOList2 = new ArrayList<>();
		List<FinancialDataDTO> financialDataDTOList3 = new ArrayList<>();

		for (FinancialData financialData : financialDataList) {

			int year = financialData.getYear();

			if (year == year1) {
				financialDataList1.add(financialData);
			} else if (year == year2) {
				financialDataList2.add(financialData);
			} else {
				financialDataList3.add(financialData);
			}
		}

		if (!financialDataList1.isEmpty()) {
			financialDataDTOList1 = calculateFinanceData(financialDataDTOList1,
					financialDataList1, typeOfFinanceData, typeOfFinanceData1);
		}

		if (!financialDataList2.isEmpty()) {
			financialDataDTOList2 = calculateFinanceData(financialDataDTOList2,
					financialDataList2, typeOfFinanceData, typeOfFinanceData1);

		}

		if (!financialDataList3.isEmpty()) {
			financialDataDTOList3 = calculateFinanceData(financialDataDTOList3,
					financialDataList3, typeOfFinanceData, typeOfFinanceData1);
		}

		if (!financialDataDTOList1.isEmpty() & !financialDataDTOList2.isEmpty()
				& !financialDataDTOList3.isEmpty()) {
			financialDataDTOList1.addAll(financialDataDTOList2);
			financialDataDTOList1.addAll(financialDataDTOList3);
		}

		if (!financialDataDTOList1.isEmpty() & !financialDataDTOList2.isEmpty()) {
			financialDataDTOList1.addAll(financialDataDTOList2);
		}
		return financialDataDTOList1;

	}

}
