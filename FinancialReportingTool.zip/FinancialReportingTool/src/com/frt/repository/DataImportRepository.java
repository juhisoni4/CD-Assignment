package com.frt.repository;


public interface DataImportRepository {
	
	
}
