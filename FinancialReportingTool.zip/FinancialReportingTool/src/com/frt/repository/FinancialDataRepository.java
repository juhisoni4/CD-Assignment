package com.frt.repository;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.frt.model.Client;
import com.frt.model.FinancialData;
import com.frt.model.FinancialData.Month;

public interface FinancialDataRepository {

	public void saveFinanceData(FinancialData financialData);
	
	public FinancialData getaddFinanceDataById(Long id);
	
	public List<FinancialData> getAlladdFinanceData();
	
	public List<FinancialData> search(FinancialData FinancialData);
	
	public List<FinancialData> getFinancialDataOfYear(Date date1, Date date2);
	
	public List<FinancialData> getFinanceDataByClient(Client client, Date date1, Date date2,String typeOfData);
	
	
}
