package com.frt.repository.impl;

import org.springframework.stereotype.Repository;

import com.frt.repository.DataImportRepository;

@Repository
public class DataImportRepositoryImpl implements DataImportRepository {	


}
