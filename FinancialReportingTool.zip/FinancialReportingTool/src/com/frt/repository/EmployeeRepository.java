package com.frt.repository;

import java.util.Date;
import java.util.List;

import com.frt.model.Employee;
import com.frt.model.FinancialData;

public interface EmployeeRepository {

	public void saveEmployee(Employee employee);

	public Employee getEmployeetById(Long id);

	public List<Employee> getAllEmployee();
	
	public List<Employee> search(Employee employee);
	
	public List<FinancialData> getFinanceDataByProjectManager(Employee employee, Date date1, Date date2);
	
	public List<FinancialData> getFinanceDataOfResources();
	
	//public List<Employee> searchWithoutResourceCode(Employee employee);

}
